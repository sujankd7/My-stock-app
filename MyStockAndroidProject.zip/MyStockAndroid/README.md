# My Stock — Android / Google Play preparation

This project packages the My Stock HTML app as an Android WebView app.

## Included
- My Stock stock maintenance, reports, PDF/share features and product/pack-size management.
- Offline-first localStorage data.
- Google Sheets cloud account backup/restore using the supplied multi-user Apps Script backend.
- Email + password account separation: each user's cloud data is stored under a unique user ID.
- Local JSON backup export as an extra recovery option.
- WebView file chooser/download handling for future import/share flows.
- Target SDK 36.

## First-time cloud setup
1. Create a Google Sheet.
2. Extensions → Apps Script.
3. Paste `My_Stock_Google_Apps_Script_MultiUser.gs`.
4. Run `setup()` once and approve permissions.
5. Deploy → New deployment → Web app.
6. Execute as: Me. Who has access: Anyone.
7. Copy the `/exec` URL into My Stock → Cloud Backup.
8. Create an account, then press Backup Now.

## Build
Open `MyStockAndroid` in Android Studio, sync Gradle, run on a device, then generate a signed AAB for Play Store.

## Important Play Store work before release
- Use a final unique application ID and signing key.
- Add a final app icon and screenshots.
- Publish a public privacy policy URL matching actual data handling.
- Complete Data safety, content rating and store listing.
- Test cloud login, backup, restore, offline use, PDF/share and Android back navigation on multiple devices.
