/** My Stock - Multi User Google Sheets Cloud Backend
 * One Google Sheet can safely store many My Stock accounts.
 * Deploy as Web App: Execute as Me, Who has access: Anyone.
 */
const USERS_SHEET='Users';
const DATA_SHEET='Data';
const SESSION_TTL_SECONDS=60*60*24*30; // 30 days

function setup(){
  const ss=SpreadsheetApp.getActive();
  let u=ss.getSheetByName(USERS_SHEET); if(!u) u=ss.insertSheet(USERS_SHEET);
  let d=ss.getSheetByName(DATA_SHEET); if(!d) d=ss.insertSheet(DATA_SHEET);
  if(u.getLastRow()===0) u.appendRow(['userId','email','passwordHash','createdAt','active']);
  if(d.getLastRow()===0) d.appendRow(['userId','updatedAt','payloadJson']);
  return 'My Stock Cloud is ready';
}
function doGet(){
  return HtmlService.createHtmlOutput('<!doctype html><html><body><script>window.parent.postMessage({ok:true,info:"My Stock Cloud online"},"*");</script></body></html>')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
function doPost(e){
  let r={ok:false,error:'Unknown error'};
  try{
    setup();
    const p=e&&e.parameter||{};
    const action=p.action||'';
    if(action==='signup') r=signup_(p.email,p.password);
    else if(action==='login') r=login_(p.email,p.password);
    else if(action==='save') r=save_(p.session,p.payload);
    else if(action==='load') r=load_(p.session);
    else if(action==='logout') r=logout_(p.session);
    else r={ok:false,error:'Invalid action'};
  }catch(err){r={ok:false,error:String(err.message||err)}}
  return response_(r);
}
function response_(obj){
  const safe=JSON.stringify(obj).replace(/</g,'\\u003c');
  const html='<!doctype html><html><body><script>window.parent.postMessage('+safe+',"*");</script></body></html>';
  return HtmlService.createHtmlOutput(html).setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}
function normalizeEmail_(email){return String(email||'').trim().toLowerCase()}
function validate_(email,password){
  email=normalizeEmail_(email); password=String(password||'');
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Valid email required');
  if(password.length<8 || password.length>128) throw new Error('Password must be 8-128 characters');
  return {email,password};
}
function hash_(s){
  const bytes=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,s,Utilities.Charset.UTF_8);
  return bytes.map(b=>{const n=b<0?b+256:b;return ('0'+n.toString(16)).slice(-2)}).join('');
}
function uuid_(){return Utilities.getUuid()}
function signup_(email,password){
  const v=validate_(email,password), sh=SpreadsheetApp.getActive().getSheetByName(USERS_SHEET), vals=sh.getDataRange().getValues();
  for(let i=1;i<vals.length;i++) if(String(vals[i][1]).toLowerCase()===v.email) return {ok:false,error:'এই email দিয়ে account আগে থেকেই আছে। Login করুন।'};
  const id=uuid_(); sh.appendRow([id,v.email,hash_(v.password),new Date(),true]);
  const token=issueSession_(id); return {ok:true,sessionToken:token,userId:id};
}
function login_(email,password){
  const v=validate_(email,password), sh=SpreadsheetApp.getActive().getSheetByName(USERS_SHEET), vals=sh.getDataRange().getValues();
  for(let i=1;i<vals.length;i++) if(String(vals[i][1]).toLowerCase()===v.email){
    if(vals[i][4]===false) return {ok:false,error:'Account inactive'};
    if(String(vals[i][2])!==hash_(v.password)) return {ok:false,error:'Email বা Password ভুল'};
    return {ok:true,sessionToken:issueSession_(String(vals[i][0])),userId:String(vals[i][0])};
  }
  return {ok:false,error:'Account পাওয়া যায়নি। আগে নতুন Account তৈরি করুন।'};
}
function issueSession_(userId){
  const token=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');
  const props=PropertiesService.getScriptProperties();
  const all=JSON.parse(props.getProperty('SESSIONS')||'{}');
  all[token]={userId:userId,expires:Date.now()+SESSION_TTL_SECONDS*1000};
  Object.keys(all).forEach(k=>{if(all[k].expires<Date.now()) delete all[k]});
  props.setProperty('SESSIONS',JSON.stringify(all)); return token;
}
function userFromSession_(token){
  token=String(token||''); if(!token) throw new Error('Login required');
  const props=PropertiesService.getScriptProperties(), all=JSON.parse(props.getProperty('SESSIONS')||'{}'), s=all[token];
  if(!s || s.expires<Date.now()){if(s){delete all[token];props.setProperty('SESSIONS',JSON.stringify(all))}throw new Error('Session expired. Login again.')}
  return s.userId;
}
function save_(session,payload){
  const uid=userFromSession_(session); if(!payload) throw new Error('No payload');
  const obj=JSON.parse(payload); if(obj.app!=='My Stock') throw new Error('Invalid app payload');
  const sh=SpreadsheetApp.getActive().getSheetByName(DATA_SHEET), vals=sh.getDataRange().getValues();
  let row=-1; for(let i=1;i<vals.length;i++) if(String(vals[i][0])===uid){row=i+1;break}
  const now=new Date(); if(row<0) sh.appendRow([uid,now,JSON.stringify(obj)]); else sh.getRange(row,1,1,3).setValues([[uid,now,JSON.stringify(obj)]]);
  return {ok:true,savedAt:now.toISOString()};
}
function load_(session){
  const uid=userFromSession_(session), sh=SpreadsheetApp.getActive().getSheetByName(DATA_SHEET), vals=sh.getDataRange().getValues();
  for(let i=1;i<vals.length;i++) if(String(vals[i][0])===uid){return {ok:true,data:JSON.parse(String(vals[i][2]||'{}')),updatedAt:new Date(vals[i][1]).toISOString()}}
  return {ok:false,error:'এই account-এর কোনো backup পাওয়া যায়নি।'};
}
function logout_(session){
  const props=PropertiesService.getScriptProperties(), all=JSON.parse(props.getProperty('SESSIONS')||'{}'); delete all[String(session||'')]; props.setProperty('SESSIONS',JSON.stringify(all)); return {ok:true};
}
