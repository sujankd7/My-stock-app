# My Stock Privacy Policy — Template

**Last updated:** [DATE]

My Stock is a stock/inventory management application. If Cloud Backup is enabled, the app sends account information and the inventory data you choose to back up to a Google Apps Script service connected to a Google Sheet controlled by the account owner.

## Data stored
- Email address used for the My Stock cloud account.
- A server-side hash of the account password.
- Inventory/stock data, transactions and custom products submitted for backup.
- Account and backup timestamps.

## Why data is used
Data is used to authenticate the account and to provide cloud backup and restore functionality.

## Local data
The app also stores operational data locally on the device so it can work offline.

## Sharing
My Stock does not intentionally sell personal information. Cloud data is stored in the Google Sheet/Apps Script environment configured by the app owner.

## Contact
[YOUR NAME / BUSINESS]
[CONTACT EMAIL]

Replace this template with a final public privacy policy before publishing to Google Play.
