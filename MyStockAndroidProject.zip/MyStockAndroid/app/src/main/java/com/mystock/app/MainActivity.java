package com.mystock.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.DownloadListener;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_PICKER=1001;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(fileCallback!=null) fileCallback.onReceiveValue(null);
                fileCallback=cb;
                try{ Intent i=params.createIntent(); startActivityForResult(i,FILE_PICKER); return true; }
                catch(Exception e){ fileCallback=null; return false; }
            }
        });
        web.setDownloadListener((url,userAgent,contentDisposition,mimetype,contentLength)->{
            try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }catch(Exception ignored){}
        });
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        if(requestCode==FILE_PICKER && fileCallback!=null){
            Uri[] r=null; if(resultCode==RESULT_OK && data!=null){
                Uri u=data.getData(); if(u!=null) r=new Uri[]{u};
            }
            fileCallback.onReceiveValue(r); fileCallback=null;
        }
        super.onActivityResult(requestCode,resultCode,data);
    }
    @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
